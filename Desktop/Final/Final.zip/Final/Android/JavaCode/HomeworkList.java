package com.example.xin.myapplication;

public class HomeworkList {
    String title;
    String attachment_id;

    public String getTitle() {
        return title;
    }

    public String getAttached_id() {
        return attachment_id;
    }
}
