package com.example.xin.myapplication;

import android.util.Log;

public class SimpleReceive {
    //private String token ;
    private String message;
    private int status_code;

//    public String getToken() {
//        return token;
//    }

    public int getStatus_code() {
        return status_code;
    }

    public String getMessage() {
        return message;
    }

}
